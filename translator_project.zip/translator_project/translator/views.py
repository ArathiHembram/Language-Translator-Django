from django.shortcuts import render
from googletrans import Translator, LANGUAGES
import mysql.connector

def translate_text(request):
    translated_text = ""
    input_text = ""
    selected_lang = ""

    # Database connection
    conn = mysql.connector.connect(
        host="localhost",
        user="Arathi",  # Replace with your MySQL username
        password="tiger",  # Replace with your MySQL password
        database="Translator"  # Replace with your database name
    )
    cursor = conn.cursor()

    if request.method == "POST":
        input_text = request.POST.get("input_text")
        selected_lang = request.POST.get("language")

        # Translation logic
        if input_text:
            translator = Translator(service_urls=['translate.google.com'])
            translation = translator.translate(input_text, dest=selected_lang)
            translated_text = translation.text

            # Save translation to the database
            cursor.execute("INSERT INTO TRANSLATIONS (INPUT, OUTPUT) VALUES (%s, %s)", (input_text, translated_text))
            conn.commit()

    # Get list of languages for dropdown
    languages = LANGUAGES
    return render(request, 'translator/index.html', {
        'translated_text': translated_text,
        'input_text': input_text,
        'languages': languages,
        'selected_lang': selected_lang,
    })
